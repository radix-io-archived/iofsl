#!/usr/bin/env python
'''
Created on Nov 9, 2010

@author: Rico
'''
import os,sys


class Mail:
    
    def dwnld_mail(self):
        os.system("./downld_error")
        
    def configure_mail(self):
        os.system("./configure_error")
        

    